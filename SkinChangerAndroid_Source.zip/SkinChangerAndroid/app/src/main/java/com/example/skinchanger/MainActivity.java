package com.example.skinchanger;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREFS = "skin_changer_prefs";
    private static final String KEY_FAVORITES = "favorites";
    private static final String KEY_SELECTED = "selected";
    private SharedPreferences prefs;
    private LinearLayout catalog;
    private TextView filterButton;
    private boolean favoritesOnly = false;
    private String selectedId = "crimson";
    private Set<String> favorites = new HashSet<>();

    private final List<Skin> skins = Arrays.asList(
        new Skin("crimson", "Crimson Pulse", "RIFLE • DEMO SKIN", "✦", "#FF3038", "#7A1018"),
        new Skin("neon", "Neon Circuit", "SMG • DEMO SKIN", "⌁", "#FF4F9A", "#541B6D"),
        new Skin("arctic", "Arctic Shadow", "SNIPER • DEMO SKIN", "❄", "#A6D9FF", "#253D63"),
        new Skin("ember", "Ember Strike", "PISTOL • DEMO SKIN", "♨", "#FF9B42", "#702B1D"),
        new Skin("toxic", "Toxic Bloom", "RIFLE • DEMO SKIN", "☣", "#B8FF58", "#31521E"),
        new Skin("void", "Void Runner", "KNIFE • DEMO SKIN", "◆", "#B5A1FF", "#30205F")
    );

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10, 10, 13));
        getWindow().setNavigationBarColor(Color.rgb(10, 10, 13));
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        selectedId = prefs.getString(KEY_SELECTED, "crimson");
        favorites = new HashSet<>(prefs.getStringSet(KEY_FAVORITES, new HashSet<>()));
        buildUi();
        renderCatalog();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10, 10, 13));
        root.setPadding(dp(18), dp(14), dp(18), 0);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView logo = new TextView(this);
        logo.setText("SC");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(19);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round("#FF3038", 12));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        header.addView(logo, logoLp);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, 0, 0);
        TextView title = text("SKIN CHANGER", 20, "#FFFFFF", true);
        TextView subtitle = text("DEMO CATALOG  •  ANDROID", 10, "#A5A5AE", true);
        titleCol.addView(title);
        titleCol.addView(subtitle);
        header.addView(titleCol, new LinearLayout.LayoutParams(0, -2, 1));

        TextView version = text("v1.0", 11, "#FF656B", true);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(round("#281114", 12));
        header.addView(version);
        root.addView(header);

        TextView notice = text("CATALOG MODE  •  DOES NOT APPLY SKINS IN-GAME", 10, "#FF858A", true);
        notice.setPadding(dp(12), dp(12), dp(12), dp(12));
        notice.setBackground(round("#201014", 12));
        LinearLayout.LayoutParams noticeLp = new LinearLayout.LayoutParams(-1, -2);
        noticeLp.topMargin = dp(18);
        root.addView(notice, noticeLp);

        TextView section = text("YOUR COLLECTION", 13, "#FFFFFF", true);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.topMargin = dp(22);
        root.addView(section, sectionLp);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        filters.setPadding(0, dp(12), 0, dp(10));

        TextView allButton = filterChip("ALL SKINS", false);
        filterButton = filterChip("★ FAVORITES", true);
        allButton.setOnClickListener(v -> {
            favoritesOnly = false;
            updateFilterStyles(filters);
            renderCatalog();
        });
        filterButton.setOnClickListener(v -> {
            favoritesOnly = true;
            updateFilterStyles(filters);
            renderCatalog();
        });
        filters.addView(allButton);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-2, dp(38));
        chipLp.leftMargin = dp(8);
        filters.addView(filterButton, chipLp);
        root.addView(filters);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        catalog = new LinearLayout(this);
        catalog.setOrientation(LinearLayout.VERTICAL);
        catalog.setPadding(0, dp(2), 0, dp(18));
        scroll.addView(catalog);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("SELECTED SKIN IS SAVED ON THIS DEVICE", 9, "#777780", true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(12), 0, dp(16));
        root.addView(footer);

        setContentView(root);
    }

    private void updateFilterStyles(LinearLayout filters) {
        if (filters.getChildCount() < 2) return;
        styleChip((TextView) filters.getChildAt(0), !favoritesOnly);
        styleChip((TextView) filters.getChildAt(1), favoritesOnly);
    }

    private TextView filterChip(String label, boolean active) {
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setGravity(Gravity.CENTER);
        chip.setTextSize(11);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        chip.setPadding(dp(14), 0, dp(14), 0);
        styleChip(chip, active);
        return chip;
    }

    private void styleChip(TextView chip, boolean active) {
        chip.setTextColor(Color.parseColor(active ? "#FFFFFF" : "#A5A5AE"));
        chip.setBackground(round(active ? "#D9232E" : "#1B1B22", 10));
    }

    private void renderCatalog() {
        catalog.removeAllViews();
        int shown = 0;
        for (Skin skin : skins) {
            if (favoritesOnly && !favorites.contains(skin.id)) continue;
            shown++;
            catalog.addView(makeCard(skin));
            LinearLayout.LayoutParams spacer = new LinearLayout.LayoutParams(1, dp(10));
            catalog.addView(new View(this), spacer);
        }
        if (shown == 0) {
            TextView empty = text("No favorites yet. Tap ☆ on a skin to save it.", 13, "#A5A5AE", false);
            empty.setPadding(dp(8), dp(24), dp(8), dp(24));
            catalog.addView(empty);
        }
    }

    private View makeCard(Skin skin) {
        boolean isSelected = skin.id.equals(selectedId);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(10), dp(12));
        card.setBackground(round(isSelected ? "#261317" : "#17171D", 16));
        card.setOnClickListener(v -> {
            selectedId = skin.id;
            prefs.edit().putString(KEY_SELECTED, selectedId).apply();
            Toast.makeText(this, skin.name + " selected (demo only)", Toast.LENGTH_SHORT).show();
            renderCatalog();
        });

        LinearLayout preview = new LinearLayout(this);
        preview.setGravity(Gravity.CENTER);
        preview.setBackground(gradient(skin.color1, skin.color2));
        TextView symbol = text(skin.symbol, 30, "#FFFFFF", true);
        symbol.setGravity(Gravity.CENTER);
        preview.addView(symbol, new LinearLayout.LayoutParams(-1, -1));
        card.addView(preview, new LinearLayout.LayoutParams(dp(76), dp(76)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), 0, dp(4), 0);
        TextView name = text(skin.name, 15, "#FFFFFF", true);
        TextView type = text(skin.type, 9, "#9A9AA4", true);
        LinearLayout.LayoutParams typeLp = new LinearLayout.LayoutParams(-1, -2);
        typeLp.topMargin = dp(6);
        info.addView(name);
        info.addView(type, typeLp);
        if (isSelected) {
            TextView selected = text("✓ SELECTED", 9, "#FF646B", true);
            LinearLayout.LayoutParams selectedLp = new LinearLayout.LayoutParams(-1, -2);
            selectedLp.topMargin = dp(8);
            info.addView(selected, selectedLp);
        }
        card.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

        TextView star = text(favorites.contains(skin.id) ? "★" : "☆", 27,
                favorites.contains(skin.id) ? "#FFCF4A" : "#9A9AA4", true);
        star.setGravity(Gravity.CENTER);
        star.setContentDescription("Toggle favorite");
        star.setOnClickListener(v -> {
            if (favorites.contains(skin.id)) favorites.remove(skin.id);
            else favorites.add(skin.id);
            prefs.edit().putStringSet(KEY_FAVORITES, new HashSet<>(favorites)).apply();
            renderCatalog();
        });
        card.addView(star, new LinearLayout.LayoutParams(dp(42), dp(54)));

        if (isSelected) {
            card.setForeground(roundStroke("#261317", "#FF3038", 16));
        }
        return card;
    }

    private TextView text(String value, int size, String color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(Color.parseColor(color));
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable round(String color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(color));
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable roundStroke(String fill, String stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.TRANSPARENT);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.parseColor(stroke));
        return d;
    }

    private GradientDrawable gradient(String first, String second) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor(first), Color.parseColor(second)});
        d.setCornerRadius(dp(13));
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class Skin {
        final String id, name, type, symbol, color1, color2;
        Skin(String id, String name, String type, String symbol, String color1, String color2) {
            this.id = id;
            this.name = name;
            this.type = type;
            this.symbol = symbol;
            this.color1 = color1;
            this.color2 = color2;
        }
    }
}
